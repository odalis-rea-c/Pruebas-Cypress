#Preparación de ambiente
1. npm i
2. npx cypress open
3. Se abre el CYPRESS STUDIO, elegir el navegador
4. Seleccionar el Caso de prueba
5. Ejecutar

#Las instrucciones paso a paso de la ejecución
1. Acceder a la Página de inicio
Utiliza cy.visit('https://www.demoblaze.com') para acceder al sitio web de DemoBlaze.

2. Seleccionar producto y agregar al carrito
Buscar un producto específico (por ejemplo, "Samsung galaxy s6") usando el selector cy.contains().
Hacer clic en el botón "Add to cart" en la página del producto.

3. Verificar producto en el carrito
Accede al carrito haciendo clic en el icono o enlace del carrito (cy.get('#cartur')).

4. Agregar un Segundo producto al carrito
Repite el proceso para agregar otro producto (por ejemplo, "Nokia lumia 1520").

5. Verificar que los productos estén en el carrito
Revisa nuevamente el carrito para asegurarte de que ambos productos estén presentes.

6. Completar la compra
Haz clic en el botón "Place Order" para comenzar el proceso de compra.

7. Rellenar el Formulario de compra
Completa el formulario con la información de compra (nombre, país, ciudad, número de tarjeta, fecha de vencimiento).

8. Confirmar la compra
Haz clic en el botón "Purchase" para completar la transacción.

9. Verificar la confirmación de la compra
Después de la compra, espera a que se muestre el mensaje "Thank you for your purchase!".

10. Cerrar el modal
Si aparece un modal de confirmación, haz clic en el botón "Close" para cerrarlo.

11. Redirigir al inicio
Después de cerrar el modal, redirige a la página principal de DemoBlaze usando cy.visit().


