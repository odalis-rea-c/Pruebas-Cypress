describe('Flujo de compra en DemoBlaze', () => {
    beforeEach(() => {
        cy.visit(Cypress.env('BASEURL_DEV'))
    })

    it('TC: Agregar dos productos al carrito', () => {
        // Agregar el primer producto (Samsung galaxy s6)
        cy.contains('Samsung galaxy s6').click()
        cy.contains('Add to cart').click()
        cy.on('window:alert', (str) => {
            expect(str).to.equal('Product added')
        })
        // Hacer clic en el botón "Home" para regresar a la página principal
        cy.get('.nav-link').contains('Home').click()

        // Agregar el segundo producto (Nokia lumia 1520)
        cy.contains('Nokia lumia 1520').click()
        cy.contains('Add to cart').click()
        cy.on('window:alert', (str) => {
            expect(str).to.equal('Product added')
        })

        // Ir al carrito
        cy.get('#cartur').click()

        // Verificar que los productos están en el carrito
        cy.contains('Samsung galaxy s6').should('be.visible')
        cy.contains('Nokia lumia 1520').should('be.visible')
    })
})
