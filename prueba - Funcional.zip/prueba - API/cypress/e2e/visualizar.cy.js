describe('Flujo de compra en DemoBlaze', () => {
    beforeEach(() => {
        cy.visit(Cypress.env('BASEURL_DEV')) // Usa la URL desde cypress.env.json
    })

    it('TC: Agregar dos productos al carrito y visualizarlo', () => {
        const productos = ['Samsung galaxy s6', 'Nokia lumia 1520']

        productos.forEach((producto) => {
            cy.contains(producto).click() // Seleccionar producto
            cy.contains('Add to cart').click() // Agregar al carrito

            // Validar la alerta de confirmación
            cy.on('window:alert', (str) => {
                expect(str).to.equal('Product added')
            })

            // Hacer clic en el botón "Home" para regresar a la página principal
            cy.get('.nav-link').contains('Home').click()
        })

        // Ir al carrito y visualizarlo
        cy.get('#cartur').click()  // Hacer clic en el enlace del carrito

        // Verificar que los productos están en el carrito
        productos.forEach((producto) => {
            cy.contains(producto).should('be.visible') // Verificar que cada producto esté en el carrito
        })
    })
})
