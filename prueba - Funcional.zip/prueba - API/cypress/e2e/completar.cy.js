describe('Flujo de compra en DemoBlaze', () => {
    beforeEach(() => {
        cy.visit(Cypress.env('BASEURL_DEV')) // Usa la URL desde cypress.env.json
    })

    it('TC: Completar el formulario de compra', () => {
        const productos = ['Samsung galaxy s6', 'Nokia lumia 1520']

        productos.forEach((producto) => {
            cy.contains(producto).click() // Seleccionar producto
            cy.contains('Add to cart').click() // Agregar al carrito

            // Validar la alerta de confirmación
            cy.on('window:alert', (str) => {
                expect(str).to.equal('Product added')
            })

            // Hacer clic en el botón "Home" para regresar a la página principal
            cy.get('.nav-link').contains('Home').click()
        })

        // Ir al carrito y visualizarlo
        cy.get('#cartur').click()

        // Verificar que los productos están en el carrito
        productos.forEach((producto) => {
            cy.contains(producto).should('be.visible') // Verificar que cada producto esté en el carrito
        })

        // Completar el formulario de compra
        cy.contains('Place Order').click() // Hacer clic en "Place Order"

        // Rellenar los campos del formulario
        cy.get('#name').type('Odalis Rea') // Nombre
        cy.get('#country').type('Ecuador') // País
        cy.get('#city').type('Quito') // Ciudad
        cy.get('#card').type('1234567890123456') // Número de tarjeta
        cy.get('#month').type('12') // Mes de expiración
        cy.get('#year').type('2025') // Año de expiración

        // Hacer clic en "Purchase"
        cy.contains('Purchase').click()

        // Verificar que el mensaje de compra exitosa se muestre
        cy.contains('Thank you for your purchase!').should('be.visible')
    })
})
